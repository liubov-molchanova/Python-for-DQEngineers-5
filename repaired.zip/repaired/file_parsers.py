import os
import xml.etree.ElementTree as Tree
import json
import re
from publications import News, Ads, Healthy_breakfast
from DB_connection import DBConnection
from datetime import date, datetime, timedelta

class FileParser():
    def __init__(self, input_file):
        self.input_file = input_file

    def remove(self):
        os.remove(self.input_file)

class XMLParser(FileParser):
    def __init__(self, input_file):
        super().__init__(input_file)

    def parse_xml(self, rows):
        processed_row_cnt = 0
        root = Tree.parse(self.input_file).getroot()
        for child in root:
            text = getattr(child.find('text'), 'text', '\n')
            name = getattr(child.find('name'), 'text', '\n')
            city = getattr(child.find('city'), 'text', '\n')
            ingredients = getattr(child.find('ingredients'), 'text', '\n')
            if child.attrib['type'] == "news":
                news = News(text=text, name=name, place=city)
                news.filling_document()
                data_base = DBConnection()
                data_base.insert_into_db('News', name=name, text=text, city=city,
                                            date=str(datetime.now().strftime("%d/%m/%Y %H:%M:%S")))
            elif child.attrib['type'] == "ads":
                ads = Ads(text=text, name=name)
                ads.filling_document()
                data_base = DBConnection()
                data_base.insert_into_db('Ads', name=name, text=text, date=str(date.today() + timedelta(days=30)))
            elif child.attrib['type'] == "healthy_breakfast":
                healthy_breakfast = Healthy_breakfast(text=text, name=name, ingredients=ingredients)
                healthy_breakfast.filling_document()
                data_base = DBConnection()
                data_base.insert_into_db('Healthy breakfast', name=name, text=text, ingredients=ingredients,
                                            date=str(datetime.now().strftime("%d/%m/%Y %H:%M:%S")))
            processed_row_cnt += 1
            if processed_row_cnt >= rows:
                break

class JSONParser(FileParser):
    def __init__(self, input_file):
        super().__init__(input_file)

    def parse_json(self, rows):
        processed_row_cnt = 0
        root = json.load(open(self.input_file))
        for ind, dict_ in enumerate(root):
            for key, val in dict_.items():
                # if rows > ind:
                    if key == 'type' and val == 'Healthy breakfast':
                        healthy_breakfast = Healthy_breakfast(text=dict_['text'], name=dict_['name'], ingredients=dict_['ingredients'])
                        healthy_breakfast.filling_document()
                        data_base = DBConnection()
                        data_base.insert_into_db('Healthy breakfast', text=dict_['text'], name=dict_['name'], ingredients=dict_['ingredients'], date=str(date.today()))
                    elif key == 'type' and val == 'ads':
                        ads = Ads(text=dict_['text'], name=dict_['name'])
                        ads.filling_document()
                        data_base = DBConnection()
                        data_base.insert_into_db('Ads', text=dict_['text'], name=dict_['name'], date=str(date.today() + timedelta(days=30)))
                    elif key == 'type' and val == 'news':
                        news = News(text=dict_['text'], name=dict_['name'], place=dict_['city'])
                        news.filling_document()
                        data_base = DBConnection()
                        data_base.insert_into_db('News', text=dict_['text'], name=dict_['name'], place=dict_['city'], date=str(datetime.now().strftime("%d/%m/%Y %H:%M:%S")))
            processed_row_cnt += 1
            if processed_row_cnt >= rows:
                break

class TXTParser(FileParser):
    def __init__(self, input_file):
        super().__init__(input_file)

    def parse_txt(self, rows):
        processed_row_cnt = 0
        source_file_open = open(self.input_file, 'r').read()
        with open('Final.txt', 'a') as f:
            self.text = re.split('\\n', source_file_open)
            for info in self.text:
                f.write(info + '\n')
                processed_row_cnt += 1
                if processed_row_cnt >= rows:
                    break