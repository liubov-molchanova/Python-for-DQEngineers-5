import pyodbc

class DBConnection:
    def __init__(self, db_name='sqlnews.db'):
        self.list_for_db = []
        with pyodbc.connect("DRIVER={SQLite3 ODBC Driver};"
                            "Direct=True;"
                            "String Types= Unicode;"
                            f"Database={db_name}",
                            autocommit=True) as self.connection:
            with self.connection.cursor() as self.cursor:
                # self.cursor.execute('DROP TABLE news')
                # self.cursor.execute('DROP TABLE ads')
                # self.cursor.execute('DROP TABLE break')
                self.cursor.execute('''CREATE TABLE IF NOT EXISTS news (
                                    name TEXT NOT NULL, text TEXT NOT NULL, city TEXT NOT NULL, date TEXT DEFAULT CURRENT_DATE NOT NULL, PRIMARY KEY(name,  date, city));''')
                self.cursor.execute('''CREATE TABLE IF NOT EXISTS ads (
                                    name TEXT NOT NULL, text TEXT NOT NULL, date TEXT DEFAULT CURRENT_DATE NOT NULL, PRIMARY KEY(text, date));''')
                self.cursor.execute('''CREATE TABLE IF NOT EXISTS break (
                                    name TEXT NOT NULL, ingredients TEXT NOT NULL, text TEXT, date TEXT DEFAULT CURRENT_DATE NOT NULL, PRIMARY KEY(name));''')

    def insert_into_db(self, type, **kwargs):
        publication_type = type
        if publication_type == 'News':
            try:
                self.cursor.execute(f"INSERT INTO news VALUES"
                                    f"""("{kwargs["name"]}", "{kwargs["text"]}", "{kwargs["city"]}", "{kwargs["date"]}\")""")
            except pyodbc.Error as err:
                unique = "('HY000'"
                error_code = ''.join(str(err)).split(',')
                if unique in error_code:
                    print('Attention! Duplicate row in "news" table!')
        elif publication_type == 'Ads':
            try:
                self.cursor.execute(f"INSERT INTO ads VALUES"
                                    f"""("{kwargs["name"]}", "{kwargs["text"]}", "{kwargs["date"]}\")""")
            except pyodbc.Error as err:
                    unique = "('HY000'"
                    error_code = ''.join(str(err)).split(',')
                    if unique in error_code:
                        print('Attention! Duplicate row in "ads" table!')
        if publication_type == 'Healthy breakfast':
            try:
                self.cursor.execute(f"INSERT INTO break VALUES"
                                    f"""("{kwargs["name"]}", "{kwargs["ingredients"]}", "{kwargs["text"]}", "{kwargs["date"]}\")""")
            except pyodbc.Error as err:
                unique = "('HY000'"
                error_code = ''.join(str(err)).split(',')
                if unique in error_code:
                    print('Attention! Duplicate row in "break" table!')



