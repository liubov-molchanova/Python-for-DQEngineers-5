import re
from datetime import date, datetime, timedelta

def normal_text(text):
    split_text = re.split(r'(\.\s*|\t\n)', text)
    normalized_text = ''
    for i in split_text:
        normalized_text = normalized_text + i.capitalize()
    return normalized_text

class Publication:
    def __init__(self, text, name): # here we are using our normalization from the HW#4
        self.name = name.upper()
        self.text = normal_text(text)
        self.date = datetime.now().strftime("%m/%d/%Y, %H:%M:%S")

    def filling_document(self, doc_name='final.txt'):
        f = open(doc_name, 'a')
        f.write(self.line)
        f.close()

class News(Publication):
    def __init__(self, text, name, place):
        super().__init__(text, name)
        self.place = place.capitalize()
        self.line = f"""News -----------------\n{self.name}\n{self.text}\n{self.place}\n{str(datetime.now().strftime("%d/%m/%Y %H:%M:%S"))}\n\n"""

class Ads(Publication):
    def __init__(self, text, name):
        super().__init__(text, name)
        self.date = f"Expiration date is: {str(date.today() + timedelta(days=30))}\n"
        self.line = f"""Ads -----------------\n{self.name}\n{self.text}\n{self.date}\n\n"""

class Healthy_breakfast(Publication):
    def __init__(self, text, name, ingredients):
        super().__init__(text, name)
        self.ingredients = ingredients.capitalize()
        cooking_recommendations = f"Cooking recommendations: {self.text}\n"
        self.line = f"""Healthy breakfast -----------------\n{self.name}\n{self.ingredients}\n{cooking_recommendations}{self.date}\n\n"""
