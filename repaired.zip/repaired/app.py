from publications import News, Ads, Healthy_breakfast
from file_parsers import XMLParser, JSONParser, TXTParser
from DB_connection import DBConnection
from datetime import date, datetime, timedelta
import pyodbc

def menu():
    choice = input("If you want to insert a news manually - please, type 1.\n"
                   "If you want to insert a news from the document - please, type 2.\n"
                   "Exit - please, type 3.\n"
                   "Make your choice: \n")
    return choice

def insert_manual():
    publication_type = int(input("Please, choose a Publication type:\n"
                                 "1 - for a news\n"
                                 "2 - for an ads\n"
                                 "3 - for a healthy breakfast: \n"))
    if publication_type == 1:
        name = input("Please, enter your news Title: \n")
        text = input(f"Please, enter your publication text: \n")
        place = input("Please, enter your news Place: \n")
        news = News(text, name, place)
        news.filling_document()
        data_base = DBConnection()
        data_base.insert_into_db('News', name=name, text=text, city=place, date=str(datetime.now().strftime("%d/%m/%Y %H:%M:%S")))
    elif publication_type == 2:
        name = input("Please, enter your ads Title: \n")
        text = input(f"Please, enter your publication text: \n")
        ads = Ads(text=text, name=name)
        ads.filling_document()
        data_base = DBConnection()
        data_base.insert_into_db('Ads', name=name, text=text, date=str(date.today() + timedelta(days=30)))
    elif publication_type == 3:
        name = input("Please, enter your breakfast name: \n")
        ingredients = f"""Healthy ingredients: {input("Please, enter all necessary ingredients (only healthy ones!): ")}"""
        text = input(f"Please, enter your publication text: \n")
        healty_breakfast = Healthy_breakfast(text=text, name=name, ingredients=ingredients)
        healty_breakfast.filling_document()
        data_base = DBConnection()
        data_base.insert_into_db('Healthy breakfast', name=name, text=text, ingredients=ingredients, date=str(datetime.now().strftime("%d/%m/%Y %H:%M:%S")))

def insert_from_file():
    which_document = input("If you want to use your document, please, enter 1. \n"
                           "If you want to use a default file, please, enter 2. \n")
    while which_document not in ['1', '2']:
        which_document = input("If you want to use your document, please, enter 1. \n"
                               "If you want to use a default file, please, enter 2. \n")
    if which_document == '1':
        document_name = input("Please, enter your document name (including '.txt', '.json' or '.xml' - \n"
                              "(example: document.txt or document.json or document.xml)): \n")
    elif which_document == '2':
        document_name = 'lyuba.txt'
    publications_number = int(input('Please, define how many publications you want to use: \n'))
    try:
        with open(document_name, 'r') as file:
            pass
        if document_name.endswith('.txt'):
            txt_file = TXTParser(document_name)
            txt_file.parse_txt(publications_number)
        elif document_name.endswith('.json'):
            json_file = JSONParser(document_name)
            json_file.parse_json(publications_number)
        elif document_name.endswith('.xml'):
            xml_file = XMLParser(document_name)
            xml_file.parse_xml(publications_number)
    except (FileNotFoundError):
        print("Wrong file name!")
        quit()

if __name__ == "__main__":
    while True:
        choice = menu()
        if choice == '1':
            insert_manual()
        elif choice == '2':
            insert_from_file()
        elif choice == '3':
            break
        else:
            print('Wrong choice! Try again.')

connection = pyodbc.connect("Driver=SQLite3 ODBC Driver;"
                                    "Direct=True;"
                                    "String Types= Unicode;"
                                    "Database=sqlnews.db")

cursor = connection.cursor()

select_from_ads = """SELECT * from ads"""
select_from_news = """SELECT * from news"""
select_from_break = """SELECT * from break"""

cursor.execute(select_from_ads)
records = cursor.fetchall()
cursor.execute(select_from_news)
records1 = cursor.fetchall()
cursor.execute(select_from_break)
records2 = cursor.fetchall()

print('Ads: ', records, '\nNews: ', records1, '\nBreakfast: ', records2)